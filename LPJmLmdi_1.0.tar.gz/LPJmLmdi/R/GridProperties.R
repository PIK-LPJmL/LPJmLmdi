GridProperties <- structure(function(
	##title<< 
	## Derive grid properties from an object of class 'LPJfiles'
	##description<<
	## The function reads the grid of the input files in 'LPJfiles' and computes the area per grid cell.
	
	lpjfiles,
	### list of class 'LPJinput'
	
	...
	### further arguments (currently not used)
		
	##details<<
	## No details.
	
	##references<< No reference.

	##seealso<<
	## \code{\link{LPJfiles}}	
) {

	# is there already grid information
	has.grid <- !is.null(lpjfiles$grid)
	if (!has.grid) {
		grid.pos <- c(grep("grid", lpjfiles$input$name), grep("GRID", lpjfiles$input$name))
		file.grid <- as.character(lpjfiles$input$file[grid.pos])
		grid <- ReadGrid(file.grid)
		ll <- CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs +towgs84=0,0,0")
		ncell <- nrow(grid)
		grid.sp <- try(SpatialPixelsDataFrame(grid, data=data.frame(id=1:ncell), proj4string=ll, tolerance=0.5), silent=TRUE)
		if (class(grid.sp) == "try-error") {
			grid.sp <- SpatialPointsDataFrame(grid, data=data.frame(id=1:ncell), proj4string=ll)
			grid.r <- try(raster(ext=extent(grid.sp)), silent=TRUE)
			if (class(grid.r) == "try-error") {
				ext <- extent(grid.sp)
				grid.r <- raster(xmn=ext@xmin-0.25, xmx=ext@xmax+0.25, ymn=ext@ymin-0.25, ymx=ext@ymax+0.25)
			} 
			res(grid.r) <- c(0.5, 0.5)
			grid.r[] <- NA
			grid.r[cellFromXY(grid.r, grid)] <- 1:ncell
			area.r <- raster::area(grid.r)
			area.r <- mask(area.r, grid.r)
		} else {
			grid.r <- raster(grid.sp)
			area.r <- raster::area(grid.r)
		}
		grid <- list(grid=grid.r, area=area.r, ncell=nrow(grid))
	} else {
		grid <- lpjfiles$grid
	}
	return(grid)
	### the function returns a list with 'grid' (raster of grid cells), 'area' (vector of grid cell area) and 'ncell' (number of grid cells)
})